var class_ui___testimonials =
[
    [ "retranslateUi", "class_ui___testimonials.html#a3d78b15bd8d7baf11793bdfcef983264", null ],
    [ "setupUi", "class_ui___testimonials.html#a5318933ddce45cf803fce20c7931528b", null ],
    [ "label", "class_ui___testimonials.html#ab1011d6c5be281c18787fcaeb0b6622d", null ],
    [ "submitTest", "class_ui___testimonials.html#a5b551b5141fbeac42083c318118d519e", null ],
    [ "writtenTest", "class_ui___testimonials.html#aaccac6affdf5edf3d0e2cb4e4eb7116d", null ]
];