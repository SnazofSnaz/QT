var namespaces =
[
    [ "myStd", "namespacemy_std.html", null ],
    [ "Ui", "namespace_ui.html", null ]
];