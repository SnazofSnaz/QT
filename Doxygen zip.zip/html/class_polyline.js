var class_polyline =
[
    [ "Polyline", "class_polyline.html#a2587221692617dcbd2d8cf4e82d1857a", null ],
    [ "~Polyline", "class_polyline.html#af77a79ed0a14a8334cfd92cd17063fec", null ],
    [ "draw", "class_polyline.html#a5658b419b72c402aebaf4f16e85185c0", null ],
    [ "setPoints", "class_polyline.html#ae1e304bc46be696ed3148c31f49a6311", null ]
];