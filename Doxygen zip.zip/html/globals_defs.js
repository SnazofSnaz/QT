var globals_defs =
[
    [ "_", "globals_defs.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "q", "globals_defs_q.html", null ],
    [ "w", "globals_defs_w.html", null ]
];