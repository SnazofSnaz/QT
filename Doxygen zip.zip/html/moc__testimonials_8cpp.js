var moc__testimonials_8cpp =
[
    [ "qt_meta_stringdata_Testimonials_t", "structqt__meta__stringdata___testimonials__t.html", "structqt__meta__stringdata___testimonials__t" ],
    [ "QT_MOC_LITERAL", "moc__testimonials_8cpp.html#a75bb9482d242cde0a06c9dbdc6b83abe", null ]
];