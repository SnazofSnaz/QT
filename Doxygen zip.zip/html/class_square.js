var class_square =
[
    [ "Square", "class_square.html#a98935533394c6a7d9ba870a1df098a02", null ],
    [ "~Square", "class_square.html#ab0677a46d02aa78bc0b7be8c06f9dc37", null ],
    [ "area", "class_square.html#a21c3583a4edb209cae8bd110cd09998d", null ],
    [ "draw", "class_square.html#a0d057d0953c8d882c54a162640836942", null ],
    [ "perimeter", "class_square.html#afef108dc40b4f90377df428147394d38", null ],
    [ "setSquare", "class_square.html#a485be283ee35e0c795d5f19a62f18ed7", null ]
];