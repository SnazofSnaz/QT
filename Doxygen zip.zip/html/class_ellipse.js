var class_ellipse =
[
    [ "Ellipse", "class_ellipse.html#af31f4f441414671f76c60b03516eb5d6", null ],
    [ "~Ellipse", "class_ellipse.html#af7b546b29a2f8ce3494f9d02143a621c", null ],
    [ "area", "class_ellipse.html#abdcc9bf2ca75e53000eecd7fce16d1ea", null ],
    [ "draw", "class_ellipse.html#a59cac1130e2dba94d118ae19d063a910", null ],
    [ "perimeter", "class_ellipse.html#abb2c4bca7f3c88c16a81f6ecb9d93e5c", null ],
    [ "setEllipse", "class_ellipse.html#a7406f2fbcb4b089a8928f9d6972aff53", null ]
];