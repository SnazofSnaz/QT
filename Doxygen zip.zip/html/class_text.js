var class_text =
[
    [ "Text", "class_text.html#a93d3fa0bab86fdfbd57c4f7c89dff3ce", null ],
    [ "~Text", "class_text.html#a4e7641708dfbf9c6bbbd41e897e9139c", null ],
    [ "draw", "class_text.html#aad1b04922d9ad2db31d0e398c6db39cd", null ],
    [ "setBoundingBox", "class_text.html#afbcdd8564c6022bdcd168f3eaa2e7d58", null ],
    [ "setFont", "class_text.html#a903e8c8a5c57c8e957c86f034bb07769", null ],
    [ "setText", "class_text.html#a4b6b54c552fc1d2438008c4af67b5bd8", null ],
    [ "setTextColor", "class_text.html#a56ca255bbc931289e197ebadbd40f6be", null ],
    [ "setTextFlags", "class_text.html#ada722c24fd0abed073ec33410e1f317c", null ]
];