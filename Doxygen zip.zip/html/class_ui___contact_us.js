var class_ui___contact_us =
[
    [ "retranslateUi", "class_ui___contact_us.html#a450b14784e49048a12740d6ba6dd0ba8", null ],
    [ "setupUi", "class_ui___contact_us.html#abe9c8db1809059fa8aab6db9c1e466b2", null ],
    [ "label", "class_ui___contact_us.html#ab09ff100f1fb9ffb3ff73988830d5055", null ],
    [ "label_2", "class_ui___contact_us.html#a60e30f7dcd8c87a03e1650a1e4c71282", null ]
];