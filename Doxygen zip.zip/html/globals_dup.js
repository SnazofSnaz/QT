var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "q", "globals_q.html", null ],
    [ "s", "globals_s.html", null ],
    [ "w", "globals_w.html", null ]
];