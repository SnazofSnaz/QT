var structqt__meta__stringdata___testimonials__t =
[
    [ "data", "structqt__meta__stringdata___testimonials__t.html#a7e71b4a1c3696dc7497e1542c565e630", null ],
    [ "stringdata0", "structqt__meta__stringdata___testimonials__t.html#ae592e87f3a060802586ddab5c65a1e9a", null ]
];