var searchData=
[
  ['testimonials',['Testimonials',['../class_ui_1_1_testimonials.html',1,'Ui']]],
  ['testimonials',['Testimonials',['../class_testimonials.html',1,'Testimonials'],['../class_testimonials.html#ae5838204099009b5884242fd937a21ae',1,'Testimonials::Testimonials()']]],
  ['testimonials_2ecpp',['testimonials.cpp',['../testimonials_8cpp.html',1,'']]],
  ['testimonials_2eh',['testimonials.h',['../testimonials_8h.html',1,'']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#a93d3fa0bab86fdfbd57c4f7c89dff3ce',1,'Text::Text()'],['../class_shape.html#aaac58aa2f6760d0f06ec1710d5123e9ba9dffbf69ffba8bc38bc4e01abf4b1675',1,'Shape::Text()']]]
];
