var searchData=
[
  ['mainwindow',['MainWindow',['../class_ui_1_1_main_window.html',1,'Ui']]],
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'']]]
];
