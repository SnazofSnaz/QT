var searchData=
[
  ['nullshape',['nullShape',['../class_shape.html#aaac58aa2f6760d0f06ec1710d5123e9ba27abbb43e7b5452827e25f009fa6f6e3',1,'Shape']]]
];
