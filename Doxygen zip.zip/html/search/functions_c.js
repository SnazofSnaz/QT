var searchData=
[
  ['readshapesfile',['readShapesFile',['../classcontroller.html#a486c33f31ab85aea9849a4d7eff8d5c7',1,'controller']]],
  ['rectangle',['Rectangle',['../class_rectangle.html#a0deed87f87e92f3b48621ff91d7e544f',1,'Rectangle']]],
  ['reserve',['reserve',['../classmy_std_1_1vector.html#a50e786a02a59e689999365037ae26b3a',1,'myStd::vector::reserve(int newalloc)'],['../classmy_std_1_1vector.html#a50e786a02a59e689999365037ae26b3a',1,'myStd::vector::reserve(int newalloc)']]],
  ['resize',['resize',['../classmy_std_1_1vector.html#afe379998a362f39e2879f8e07040f63e',1,'myStd::vector::resize(int newsize)    '],['../classmy_std_1_1vector.html#afe379998a362f39e2879f8e07040f63e',1,'myStd::vector::resize(int newsize)    ']]],
  ['retranslateui',['retranslateUi',['../class_ui___contact_us.html#a450b14784e49048a12740d6ba6dd0ba8',1,'Ui_ContactUs::retranslateUi()'],['../class_ui___main_window.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow::retranslateUi()'],['../class_ui___testimonials.html#a3d78b15bd8d7baf11793bdfcef983264',1,'Ui_Testimonials::retranslateUi()']]]
];
