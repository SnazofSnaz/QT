var searchData=
[
  ['data',['data',['../structqt__meta__stringdata___contact_us__t.html#a5885c4a67c93b8b70dde30dc2662056e',1,'qt_meta_stringdata_ContactUs_t::data()'],['../structqt__meta__stringdata___main_window__t.html#a957fb65c78029817a867a0b8f29d7047',1,'qt_meta_stringdata_MainWindow_t::data()'],['../structqt__meta__stringdata___testimonials__t.html#a7e71b4a1c3696dc7497e1542c565e630',1,'qt_meta_stringdata_Testimonials_t::data()']]]
];
