var searchData=
[
  ['testimonials',['Testimonials',['../class_ui_1_1_testimonials.html',1,'Ui']]],
  ['testimonials',['Testimonials',['../class_testimonials.html',1,'']]],
  ['text',['Text',['../class_text.html',1,'']]]
];
