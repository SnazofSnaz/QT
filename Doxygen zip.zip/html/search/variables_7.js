var searchData=
[
  ['stackedwidget',['stackedWidget',['../class_ui___main_window.html#a8d440a6df1de0bc57afcdda7476d8f19',1,'Ui_MainWindow']]],
  ['statusbar',['statusbar',['../class_ui___main_window.html#a1687cceb1e2787aa1f83e50433943a91',1,'Ui_MainWindow']]],
  ['stringdata0',['stringdata0',['../structqt__meta__stringdata___contact_us__t.html#a7263815f1f2dc2354a431e042fe7389f',1,'qt_meta_stringdata_ContactUs_t::stringdata0()'],['../structqt__meta__stringdata___main_window__t.html#a1f1ccd272719feca76d3afb499061a47',1,'qt_meta_stringdata_MainWindow_t::stringdata0()'],['../structqt__meta__stringdata___testimonials__t.html#ae592e87f3a060802586ddab5c65a1e9a',1,'qt_meta_stringdata_Testimonials_t::stringdata0()']]],
  ['submittest',['submitTest',['../class_ui___testimonials.html#a5b551b5141fbeac42083c318118d519e',1,'Ui_Testimonials']]]
];
