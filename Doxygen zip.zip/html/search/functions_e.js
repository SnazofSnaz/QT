var searchData=
[
  ['testimonials',['Testimonials',['../class_testimonials.html#ae5838204099009b5884242fd937a21ae',1,'Testimonials']]],
  ['text',['Text',['../class_text.html#a93d3fa0bab86fdfbd57c4f7c89dff3ce',1,'Text']]]
];
