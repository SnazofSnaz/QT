var searchData=
[
  ['getbrush',['getBrush',['../class_shape.html#a4fff90728217432c4510dbcdbf3cd9e6',1,'Shape']]],
  ['getpainter',['getPainter',['../class_shape.html#a754ef1fcea3fbe3c3612da480ba8dd75',1,'Shape']]],
  ['getpen',['getPen',['../class_shape.html#ab3420c1972e190923410abcc36a1db78',1,'Shape']]],
  ['getshape',['getShape',['../class_shape.html#a74bce3046214e6a55e32013f171dd738',1,'Shape']]],
  ['groupbox',['groupBox',['../class_ui___main_window.html#aef7cb3be8cecfc9aaf98f036a98781ce',1,'Ui_MainWindow']]],
  ['guestbutton',['guestButton',['../class_ui___main_window.html#a06412c7db959cae70699ec9fa71ccc61',1,'Ui_MainWindow']]],
  ['guestreturn',['guestReturn',['../class_ui___main_window.html#adc810ff2631c2cd071de20030837cf84',1,'Ui_MainWindow']]]
];
