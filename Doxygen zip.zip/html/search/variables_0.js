var searchData=
[
  ['adminlandingpage',['AdminLandingPage',['../class_ui___main_window.html#ace6596d059f3339ec35f2dc613422080',1,'Ui_MainWindow']]],
  ['adminreturn',['adminReturn',['../class_ui___main_window.html#a1a7a5191a5a0c308ab976b48b518fd12',1,'Ui_MainWindow']]]
];
