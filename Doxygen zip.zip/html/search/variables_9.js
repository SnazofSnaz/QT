var searchData=
[
  ['writetest',['writeTest',['../class_ui___main_window.html#aee3a73fb809bd620c06ea74bc6889853',1,'Ui_MainWindow']]],
  ['writtentest',['writtenTest',['../class_ui___testimonials.html#aaccac6affdf5edf3d0e2cb4e4eb7116d',1,'Ui_Testimonials']]]
];
