var searchData=
[
  ['selection_5fsort',['selection_sort',['../vector_8cpp.html#a64101404ba186e61e818f9209951bfd7',1,'selection_sort(Iterator first, Iterator last):&#160;vector.cpp'],['../vector__double_8cpp.html#a64101404ba186e61e818f9209951bfd7',1,'selection_sort(Iterator first, Iterator last):&#160;vector_double.cpp']]],
  ['set_5fstorage',['set_storage',['../class_canvas.html#a9079eea1abd4920030af9418e31d7951',1,'Canvas']]],
  ['setboundingbox',['setBoundingBox',['../class_text.html#afbcdd8564c6022bdcd168f3eaa2e7d58',1,'Text']]],
  ['setbrush',['setBrush',['../class_shape.html#aee7defb916cf41a4de384bae1e8c501b',1,'Shape']]],
  ['setcircle',['setCircle',['../class_circle.html#a9514d534e0dc152df432ae06ea42886b',1,'Circle']]],
  ['setellipse',['setEllipse',['../class_ellipse.html#a7406f2fbcb4b089a8928f9d6972aff53',1,'Ellipse']]],
  ['setfont',['setFont',['../class_text.html#a903e8c8a5c57c8e957c86f034bb07769',1,'Text']]],
  ['setpen',['setPen',['../class_shape.html#a9ad9e4aeb946c5231fb357afbec2c3d8',1,'Shape']]],
  ['setpoints',['setPoints',['../class_line.html#a26d1f587b4f276102e6afac5201eb581',1,'Line::setPoints()'],['../class_polyline.html#ae1e304bc46be696ed3148c31f49a6311',1,'Polyline::setPoints()']]],
  ['setpolygon',['setPolygon',['../class_polygon.html#a7ea172d7e73f4ab6c7c42e3df6d4f62a',1,'Polygon']]],
  ['setrectangle',['setRectangle',['../class_rectangle.html#a519d87986fd63b9db73796d332741efc',1,'Rectangle']]],
  ['setselected',['setSelected',['../class_canvas.html#a812fe94992ea203421759f324fcbe004',1,'Canvas']]],
  ['setshape',['setShape',['../class_shape.html#a0e4250ceca0c776e256a2bd44d4a55d9',1,'Shape']]],
  ['setsquare',['setSquare',['../class_square.html#a485be283ee35e0c795d5f19a62f18ed7',1,'Square']]],
  ['settext',['setText',['../class_text.html#a4b6b54c552fc1d2438008c4af67b5bd8',1,'Text']]],
  ['settextcolor',['setTextColor',['../class_text.html#a56ca255bbc931289e197ebadbd40f6be',1,'Text']]],
  ['settextflags',['setTextFlags',['../class_text.html#ada722c24fd0abed073ec33410e1f317c',1,'Text']]],
  ['setupui',['setupUi',['../class_ui___contact_us.html#abe9c8db1809059fa8aab6db9c1e466b2',1,'Ui_ContactUs::setupUi()'],['../class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58',1,'Ui_MainWindow::setupUi()'],['../class_ui___testimonials.html#a5318933ddce45cf803fce20c7931528b',1,'Ui_Testimonials::setupUi()']]],
  ['shape',['Shape',['../class_shape.html#a1d2ed1f7c96457bb6413d72a0a44ff4c',1,'Shape']]],
  ['size',['size',['../classmy_std_1_1vector.html#a33ebe4dab379f466c8d3a2f08d9aa554',1,'myStd::vector::size() const '],['../classmy_std_1_1vector.html#a33ebe4dab379f466c8d3a2f08d9aa554',1,'myStd::vector::size() const ']]],
  ['square',['Square',['../class_square.html#a98935533394c6a7d9ba870a1df098a02',1,'Square']]]
];
