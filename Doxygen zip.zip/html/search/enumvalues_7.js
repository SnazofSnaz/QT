var searchData=
[
  ['text',['Text',['../class_shape.html#aaac58aa2f6760d0f06ec1710d5123e9ba9dffbf69ffba8bc38bc4e01abf4b1675',1,'Shape']]]
];
