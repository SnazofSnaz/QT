var class_rectangle =
[
    [ "Rectangle", "class_rectangle.html#a0deed87f87e92f3b48621ff91d7e544f", null ],
    [ "~Rectangle", "class_rectangle.html#a6e3ed18583022b35e04c109345d1e7d6", null ],
    [ "area", "class_rectangle.html#a6b3912c47937ed46693249ad0b8081c9", null ],
    [ "draw", "class_rectangle.html#a27e45c1ad5cb7654b044ed9442b2ab9b", null ],
    [ "perimeter", "class_rectangle.html#a1672f74c28fa25703683f13d02e182a6", null ],
    [ "setRectangle", "class_rectangle.html#a519d87986fd63b9db73796d332741efc", null ]
];