var hierarchy =
[
    [ "QDialog", null, [
      [ "ContactUs", "class_contact_us.html", null ],
      [ "Testimonials", "class_testimonials.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "controller", "classcontroller.html", null ]
    ] ],
    [ "qt_meta_stringdata_ContactUs_t", "structqt__meta__stringdata___contact_us__t.html", null ],
    [ "qt_meta_stringdata_MainWindow_t", "structqt__meta__stringdata___main_window__t.html", null ],
    [ "qt_meta_stringdata_Testimonials_t", "structqt__meta__stringdata___testimonials__t.html", null ],
    [ "QWidget", null, [
      [ "Canvas", "class_canvas.html", null ]
    ] ],
    [ "Shape", "class_shape.html", [
      [ "Circle", "class_circle.html", null ],
      [ "Ellipse", "class_ellipse.html", null ],
      [ "Line", "class_line.html", null ],
      [ "Polygon", "class_polygon.html", null ],
      [ "Polyline", "class_polyline.html", null ],
      [ "Rectangle", "class_rectangle.html", null ],
      [ "Square", "class_square.html", null ],
      [ "Text", "class_text.html", null ]
    ] ],
    [ "Ui_ContactUs", "class_ui___contact_us.html", [
      [ "Ui::ContactUs", "class_ui_1_1_contact_us.html", null ]
    ] ],
    [ "Ui_MainWindow", "class_ui___main_window.html", [
      [ "Ui::MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Ui_Testimonials", "class_ui___testimonials.html", [
      [ "Ui::Testimonials", "class_ui_1_1_testimonials.html", null ]
    ] ],
    [ "myStd::vector< T >", "classmy_std_1_1vector.html", null ]
];