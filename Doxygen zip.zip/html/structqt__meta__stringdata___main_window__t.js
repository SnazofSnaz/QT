var structqt__meta__stringdata___main_window__t =
[
    [ "data", "structqt__meta__stringdata___main_window__t.html#a957fb65c78029817a867a0b8f29d7047", null ],
    [ "stringdata0", "structqt__meta__stringdata___main_window__t.html#a1f1ccd272719feca76d3afb499061a47", null ]
];