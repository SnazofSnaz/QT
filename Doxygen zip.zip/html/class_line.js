var class_line =
[
    [ "Line", "class_line.html#abfce044bd32535d51e49ed00d401aee0", null ],
    [ "~Line", "class_line.html#af18447238883377a0071d2276a4ac0a5", null ],
    [ "draw", "class_line.html#acc50906c1b0e1852502a9730159c4293", null ],
    [ "setPoints", "class_line.html#a26d1f587b4f276102e6afac5201eb581", null ]
];