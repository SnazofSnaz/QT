var class_canvas =
[
    [ "Canvas", "class_canvas.html#aeea65f2bfc2be61bdbcaaa3a67c33185", null ],
    [ "mousePressEvent", "class_canvas.html#ac766a4e369f781943df021b80e5922c4", null ],
    [ "paintEvent", "class_canvas.html#a67dbba80855f3b4fb95c26d5012f7ccc", null ],
    [ "set_storage", "class_canvas.html#a9079eea1abd4920030af9418e31d7951", null ],
    [ "setSelected", "class_canvas.html#a812fe94992ea203421759f324fcbe004", null ]
];