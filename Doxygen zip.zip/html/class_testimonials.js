var class_testimonials =
[
    [ "Testimonials", "class_testimonials.html#ae5838204099009b5884242fd937a21ae", null ],
    [ "~Testimonials", "class_testimonials.html#a58f778dcdda4f944027493aae28b0e51", null ]
];