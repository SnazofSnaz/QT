var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8f8fd41d04f4eef23fadf20142059a54", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "keyPressEvent", "class_main_window.html#a80e7ccf1cae2967c92fc6c3d9f97f5e1", null ],
    [ "page", "class_main_window.html#aa133ba8ea6390c5d57f5c10edee76ad1", null ]
];